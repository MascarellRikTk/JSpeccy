package tv.porst.jhexview;

public interface IHexViewListener {

	void selectionChanged(long start, long length);

}
