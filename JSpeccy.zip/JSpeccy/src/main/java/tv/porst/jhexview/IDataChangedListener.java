package tv.porst.jhexview;

public interface IDataChangedListener {

	void dataChanged();

}
